(function () {

// Initialize Firebase
    var config = {
        apiKey: "AIzaSyAb9NhdUXgEumko8M6kkF8RLotpEEz3cho",
        authDomain: "lavender-127.firebaseapp.com",
        databaseURL: "https://lavender-127.firebaseio.com",
        projectId: "lavender-127",
        storageBucket: "lavender-127.appspot.com",
        messagingSenderId: "18967644527"
    };
    firebase.initializeApp(config);

    // get element
    const preObj = document.getElementById('object'); // for display json code only
    const ulList = document.getElementById('list');


    // Create ref
    const dbRefObj = firebase.database().ref().child('chi');
    const dbRefList = dbRefObj.child('food');



    // sync obj changes for display jSON code
    dbRefObj.on('value', snap =>{
        preObj.innerText = JSON.stringify(snap.val(), null, 3)

    });


    //sync list add
    dbRefList.on('child_added', snap => {
        const li = document.createElement('li');
        li.innerText = snap.val();
        li.id = snap.key;
        ulList.appendChild(li);

    });
    // On database changes
    dbRefList.on('child_changed', snap => {
       const lichanged = document.getElementById(snap.key);
       lichanged.innerText = snap.val();

    });
    //on Database delete
    dbRefList.on('child_removed', snap => {
        const liToRemove = document.getElementById(snap.key);
        liToRemove.remove();
    });

    // display second item=========================================
    const ulList2 = document.getElementById('list2');

    const dbRefList2 = dbRefObj.child('food2');

    //sync list add
    dbRefList2.on('child_added', snap => {
        const li = document.createElement('li');
        li.innerText = snap.val();
        li.id = snap.key;
        ulList.appendChild(li);

    });
    // On database changes
    dbRefList2.on('child_changed', snap => {
        const lichanged = document.getElementById(snap.key);
        lichanged.innerText = snap.val();

    });
    //on Database delete
    dbRefList2.on('child_removed', snap => {
        const liToRemove = document.getElementById(snap.key);
        liToRemove.remove();
    });

}());