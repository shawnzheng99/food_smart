// Initialize Firebase
(function () {
    const config = {
        apiKey: "AIzaSyAb9NhdUXgEumko8M6kkF8RLotpEEz3cho",
        authDomain: "lavender-127.firebaseapp.com",
        databaseURL: "https://lavender-127.firebaseio.com",
        projectId: "lavender-127",
        storageBucket: "lavender-127.appspot.com",
        messagingSenderId: "18967644527"
    };
    firebase.initializeApp(config);

    const fname = $('foodName').value;
    const fprice = $('price').value;
    const famt = $('amount').value;

    const user = firebase.auth().currentUser;
    var userid;
    var today = new Date();
    var date = today.getFullYear() + '-' + (today.getMonth() + 1) + '-' + today.getDate();

    alert(user);
    if (user === null || user === undefined) {
        console.log("Not login");
        window.location = "loginFrom.html";
    } else {
        userid = user.uid;
        console.log("logged in");
    }
//write data to database
    var c = 0;
    firebase.database().ref(uid + '/' + 'Tacking/' + 'food' + c).set({
        name: apple,
        amt: 12,
        price: 1.23,
        expire: date.toString()
    });
    c++;


})();