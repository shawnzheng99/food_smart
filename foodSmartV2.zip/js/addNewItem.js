/**
 * Created by Shawn Zheng on 2017/5/17.
 * Version 1.0
 */
var uid;
(function () {
    // Initialize Firebase
    const config = {
        apiKey: "AIzaSyDIpNijaAVY9eHLjRmgBLLNkQHZs58e_DU",
        authDomain: "foodsmart-556eb.firebaseapp.com",
        databaseURL: "https://foodsmart-556eb.firebaseio.com",
        projectId: "foodsmart-556eb",
        storageBucket: "foodsmart-556eb.appspot.com",
        messagingSenderId: "309661839555"
    };
    firebase.initializeApp(config);
    firebase.auth().onAuthStateChanged(firebaseUser => {
        if (!firebaseUser) {
            alert("Not logged in");
            // window.location="index.html";
        }else{
            uid = firebaseUser.uid;
        }

    });
}());
function send() {
    let fname = $('#foodName').val();
    let fprice = $('#price').val();
    let famt = $('#amount').val();
    let fexpire = document.getElementById('expireDate').value;
    //validation
    if(fname.length == 0 || fname.length > 20){
        alert("Invalid item name length.");
        return;
    }



    if(famt.length == 0 || famt.length > 20){
        alert("Invalid amount.");
        return;
    }
    if(fprice<=0){
        alert("Invalid price number.");
        return;
    }

    if(isNaN(Date.parse(fexpire))){
        alert("Invalid expire date.")
        return;
    }
    //create a unique key for each item.
    let foodKey = firebase.database().ref(uid + '/').child('Tracking').push().key;
    //write data to database
    console.log("Welcome!");
    firebase.database().ref(uid + '/' + 'Tracking/' + foodKey).set({
        name: fname,
        price: fprice,
        quantity: famt,
        expDate: fexpire,
        percentLeft: 100
    },function(err){
        alert("Food item added");
        console.log("data sent!");
        window.location = 'track.html';
    });

}

