(function () {


// Initialize Firebase
    const config = {
        apiKey: "AIzaSyDIpNijaAVY9eHLjRmgBLLNkQHZs58e_DU",
        authDomain: "foodsmart-556eb.firebaseapp.com",
        databaseURL: "https://foodsmart-556eb.firebaseio.com",
        projectId: "foodsmart-556eb",
        storageBucket: "foodsmart-556eb.appspot.com",
        messagingSenderId: "309661839555"
    };
    firebase.initializeApp(config);

    // get all elements
    const txtEmail = document.getElementById('email');
    const txtPWD = document.getElementById('password');
    const btnSignUp = document.getElementById('btnSignUp');


    // add signup event
    btnSignUp.addEventListener('click', e => {
        //get email and pwd
        const email = txtEmail.value;
        const pwd = txtPWD.value;
        alert(email + pwd);
        const auth = firebase.auth();
        //sign in
        const promise = auth.createUserWithEmailAndPassword(email, pwd);
        promise.catch(e => alert(e.message));
        console.log("Registered!");
    });

    //add a realtime linstener
    firebase.auth().onAuthStateChanged(firebaseUser => {
        if (firebaseUser) {
            console.log(firebaseUser);
            console.log("Logged in");
            window.location = 'track.html';
            alert("Welcome!");
        } else {
            console.log('Not logged in');

        }
    });



}());