/**
 * Created by ZhengDaye on 2017/5/17.
 */

(function () {
    const config = {
        apiKey: "AIzaSyDIpNijaAVY9eHLjRmgBLLNkQHZs58e_DU",
        authDomain: "foodsmart-556eb.firebaseapp.com",
        databaseURL: "https://foodsmart-556eb.firebaseio.com",
        projectId: "foodsmart-556eb",
        storageBucket: "foodsmart-556eb.appspot.com",
        messagingSenderId: "309661839555"
    };
    firebase.initializeApp(config);

    const txtEmail = document.getElementById('userName');
    const txtPWD = document.getElementById('pwd');
    const btnLogin = document.getElementById('btnLogin');

// add login event

    btnLogin.addEventListener('click', e => {
        //get email and pwd
        const email = txtEmail.value;
        const pwd = txtPWD.value;
        const auth = firebase.auth();
        //sign in
        const promise = auth.signInWithEmailAndPassword(email, pwd);
        promise.catch(e => alert(e.message));

    });
//add a realtime linstener
    firebase.auth().onAuthStateChanged(firebaseUser => {
        if (firebaseUser) {
            console.log(firebaseUser);
            console.log("Logged in");
            //alert("Welcome!");
            window.location = 'track.html';
        } else {
            console.log('Not logged in');

        }
    });

}());