/**
 * Created by ZhengDaye on 2017/5/18.
 */

(function () {
// Initialize Firebase
    const config = {
        apiKey: "AIzaSyDIpNijaAVY9eHLjRmgBLLNkQHZs58e_DU",
        authDomain: "foodsmart-556eb.firebaseapp.com",
        databaseURL: "https://foodsmart-556eb.firebaseio.com",
        projectId: "foodsmart-556eb",
        storageBucket: "foodsmart-556eb.appspot.com",
        messagingSenderId: "309661839555"
    };
    firebase.initializeApp(config);

    // logout event
    const btnLogout = document.getElementById('btnLogout');

    btnLogout.addEventListener('click', e => {
        firebase.auth().signOut();
        console.log("logged out");
        alert("logged out");
        window.location="index.html";
    });

}());